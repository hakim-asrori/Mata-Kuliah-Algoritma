#include <iostream>

#include <stdio.h>

using namespace std;

int main()
{
	int nilai [2][3];
	float hasil;
	
	nilai[0][0] = 0;
	nilai[0][1] = 1;
	nilai[0][2] = 2;
	nilai[1][0] = 10;
	nilai[1][1]	= 11;
	nilai[1][2] = 12;
	
	cout << "Nilai yang tersimpan pada array : "<<endl;
	cout << "Nilai[0][0] = " << nilai[0][0] << endl;
	cout << "Nilai[0][1] = " << nilai[0][1] << endl;
	cout << "Nilai[0][2] = " << nilai[0][2] << endl;
	cout << "Nilai[1][0] = " << nilai[1][0] << endl;
	cout << "Nilai[1][1] = " << nilai[1][1] << endl;
	cout << "Nilai[1][2] = " << nilai[1][2] << endl;
	
	hasil = nilai[1][2]+nilai[1][1];
	cout<<nilai[1][2]<<" + "<<nilai[1][1]<<" = "<<hasil<<endl;
	
	hasil = nilai[1][2]-nilai[1][1];
	cout<<nilai[1][2]<<" - "<<nilai[1][1]<<" = "<<hasil<<endl;	
}
