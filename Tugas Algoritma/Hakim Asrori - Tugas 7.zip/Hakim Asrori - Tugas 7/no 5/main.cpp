////////////////////
// 				  //
//  Hakim Asrori  //
// 				  //
////////////////////

#include <iostream>
#include "conio.h"

using namespace std;

int main() {

    printf("//////////////////// \n");
    printf("//                // \n");
    printf("//  Hakim Asrori  // \n");
    printf("//                // \n");
    printf("//////////////////// \n");
    printf("\n");
    printf("\n");

    int angka = 0;

	while (angka <= 10) {
		cout << "Masukkan Angka : ";
		cin >> angka;
		cout << endl;
	}

	cout << "Keluar ..." << endl;

    getch();
}
