////////////////////
// 				  //
//  Hakim Asrori  //
// 				  //
////////////////////

#include <iostream>

using namespace std;

int main() {
    int s,n;

    printf("//////////////////// \n");
    printf("//                // \n");
    printf("//  Hakim Asrori  // \n");
    printf("//                // \n");
    printf("//////////////////// \n");
    printf("\n");
    printf("\n");

	for (s = 10; s <= 50; s += 10) {

		for (n = 0; n < s; n += 10) {

			cout << s << " ";

		}

	}

	cin.get();

}
